#!/usr/bin/env python3
"""Python Essentials

Chapter 3, Script 1
"""

c = 13
f = 32+9*c/5
print( "C=", c, "F=", f)