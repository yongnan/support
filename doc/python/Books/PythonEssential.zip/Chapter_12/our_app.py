import Chapter_12.app_component

from Chapter_12.config import Config
print(__name__, Config, Config.mongo_uri, Config.some_param, Config.options)
