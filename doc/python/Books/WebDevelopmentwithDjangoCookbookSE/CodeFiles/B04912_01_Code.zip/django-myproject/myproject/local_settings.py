# -*- coding: UTF-8 -*-
from __future__ import unicode_literals

INSTALLED_APPS += (
    'debug_toolbar',
)
