from enum import Enum, auto


class Alignment(Enum):
    LEFT = auto()
    RIGHT = auto()