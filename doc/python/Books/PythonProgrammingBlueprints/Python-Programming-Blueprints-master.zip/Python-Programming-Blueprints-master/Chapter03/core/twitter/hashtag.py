class Hashtag:
    def __init__(self, name):
        self.name = name
        self.total = 0
        self.refresh_url = None
