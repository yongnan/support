from itertools import permutations
print(list(permutations('ABCDEFGHIJ')))
