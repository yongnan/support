# -*- coding: UTF-8 -*-
"""
Django settings for myproject project.
"""
from __future__ import unicode_literals

from .conf.dev import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'myproject', 'db.sqlite3'),
    }
}

### See recipe "Local settings"
try:
    execfile(os.path.join(os.path.dirname(__file__), "local_settings.py"))
except IOError:
    pass