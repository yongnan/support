const util = require('util');
const data = require('./data');

console.log(util.inspect(data));