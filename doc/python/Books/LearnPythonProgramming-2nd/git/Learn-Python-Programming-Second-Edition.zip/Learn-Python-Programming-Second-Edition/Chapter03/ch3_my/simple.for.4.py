surnames = ['Rivest', 'Shamir', 'Adleman']
for position, surname in enumerate(surnames,1):
    print(position, surname)
