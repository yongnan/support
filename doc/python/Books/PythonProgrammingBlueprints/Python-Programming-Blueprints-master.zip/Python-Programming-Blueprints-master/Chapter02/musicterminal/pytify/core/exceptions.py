class BadRequestError(Exception):
    pass