#!/usr/bin/env python3
"""Python Essentials

Chapter 4, Script 1
"""

c= float(input("Temperature, C: "))
print("f =", 32+9*c/5)