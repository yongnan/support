# -*- coding: UTF-8 -*-
default_app_config = 'bulletin_board.apps.BulletinBoardConfig'
