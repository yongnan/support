from enum import Enum, auto


class RequestType(Enum):
    GET = auto()
    PUT = auto()