
import {
    default as simple, hello, next
} from './simple2.mjs';

console.log(hello());
console.log(next());
console.log(next());
console.log(simple());
console.log(next());
console.log(next());
console.log(next());
