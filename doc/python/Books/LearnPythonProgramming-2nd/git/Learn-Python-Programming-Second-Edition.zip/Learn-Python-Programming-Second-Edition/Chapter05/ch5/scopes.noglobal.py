ex1 = [A for A in range(5)]
print(A)  # breaks: NameError: name 'A' is not defined
