// See https://github.com/nodejs/node-eps/blob/master/002-es-modules.md#4512-getting-cjs-variables-workaround
module.exports = {__dirname};