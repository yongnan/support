class EmptyResultsError(Exception):
    pass