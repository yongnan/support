This is an example project for the chapter "Database Structure" of the book "Web Development with Django Cookbook - Second Edition" by Aidas Bendoraitis.


To install requirements run:
pip install -r requirements.txt

To start, run the development server:
$ python manage.py runserver

To login to administration go to
http://127.0.0.1:8000/en/admin/
and enter username "admin" and password "admin"