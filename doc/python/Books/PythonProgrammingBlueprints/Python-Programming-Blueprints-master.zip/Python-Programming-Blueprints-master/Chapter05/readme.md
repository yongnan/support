# TempMessenger

Amend the config to point to your redis instance and rabbitmq instance.

To run, simply execute:
```
nameko run temp_messenger.service --config config.yaml
```
